#ifndef RECT_H
#define RECT_H

#include "vec2.h"

/* simple data representation of a rectangle */
class Rect {
  public:

};

#endif